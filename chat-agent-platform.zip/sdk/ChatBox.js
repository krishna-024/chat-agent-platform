import React, { useState } from "react";
import { useChatAgent } from "./useChatAgent";

export function ChatBox({ apiUrl, model }) {
  const { messages, sendMessage } = useChatAgent({ apiUrl, model });
  const [input, setInput] = useState("");

  const handleSend = () => {
    sendMessage(input);
    setInput("");
  };

  return (
    <div style={{ border: "1px solid #ccc", padding: "1rem", width: "400px" }}>
      <h3>Chat Agent</h3>
      <div style={{ minHeight: "200px", marginBottom: "1rem" }}>
        {messages.map((m, i) => (
          <p key={i}><b>{m.role}:</b> {m.text}</p>
        ))}
      </div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Type your message..."
        style={{ width: "80%" }}
      />
      <button onClick={handleSend}>Send</button>
    </div>
  );
}