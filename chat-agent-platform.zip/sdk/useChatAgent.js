import { useState } from "react";

export function useChatAgent({ apiUrl, model }) {
  const [messages, setMessages] = useState([]);

  async function sendMessage(text) {
    const res = await fetch(`${apiUrl}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, model }),
    });
    const data = await res.json();

    setMessages([...messages, { role: "user", text }, { role: "agent", text: data.reply }]);
  }

  return { messages, sendMessage };
}