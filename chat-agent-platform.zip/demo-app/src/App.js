import React from "react";
import { ChatBox } from "chat-agent-sdk";

function App() {
  return (
    <div>
      <h1>Travel Site Chatbot</h1>
      <ChatBox apiUrl="http://localhost:5000" model="openai" />
    </div>
  );
}

export default App;