import express from "express";
import { queryLLM } from "../services/llm.js";
import { fetchContent } from "../services/contentstack.js";

const router = express.Router();

router.post("/", async (req, res) => {
  const { message, model } = req.body;

  try {
    const content = await fetchContent(message);
    const response = await queryLLM(message, content, model);
    res.json({ reply: response });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Something went wrong" });
  }
});

export default router;