export async function fetchContent(query) {
  if (query.toLowerCase().includes("italy")) {
    return [
      { name: "Rome City Walk" },
      { name: "Venice Canal Tour" },
      { name: "Tuscany Wine Experience" }
    ];
  }
  return [{ name: "No matching tours found." }];
}