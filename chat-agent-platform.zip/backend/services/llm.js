export async function queryLLM(message, content, model = "openai") {
  return `You asked: "${message}". From Contentstack, I found: ${JSON.stringify(content)}`;
}